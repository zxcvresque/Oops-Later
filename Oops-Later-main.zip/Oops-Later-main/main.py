from server import app  # noqa: F401
